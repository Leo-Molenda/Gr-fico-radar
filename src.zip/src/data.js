export const stockData = [
    {
      battery: 0.6,
      design: .85,
      useful: 0.5,
      speed: 0.6,
      weight: 0.7
    },
  ];