import { BrowserRouter, Route, Routes } from "react-router-dom";
import Inicio from "./Paginas/Inicio";
import GraficoGerado from './Paginas/GraficoGerado';
import Menu from "./Componentes/Menu";

/// Dentro de Route:
/// path para a linha no url
/// element para o que vai aparecer na tela

function AppRoutes() {
  return (
    <BrowserRouter> 

      <Menu />

      <Routes> 
        <Route path="/" element= {<Inicio/>}/>
        <Route path="GraficoGerado" element= {<GraficoGerado/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;
