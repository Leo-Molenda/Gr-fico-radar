import React from 'react';

import RadarChart from 'react-svg-radar-chart';
import 'react-svg-radar-chart/build/css/index.css'




const batterys = 1
const design = 1
const useful = 1
const speed = 1
const weight = 1

class Radar extends React.Component {
  render() {

 	 const data = [
      {
        data: {
          battery: batterys,
          design: design,
          useful: useful,
          speed: speed,
          weight: weight
        },
        meta: { color: 'blue' }
      },
      {
        data: {
          battery: 1,
          design: .85,
          useful: 0.5,
          speed: 0.6,
          weight: 0.7
        },
        meta: { color: 'red' }
      }
    ];

	const captions = {
      // columns
      battery: 'Battery Capacity',
      design: 'Design',
      useful: 'Usefulness',
      speed: 'Speed',
      weight: 'Weight'
    };

    return (
      <div>
        <RadarChart
            captions={captions}
            data={data}
            size={400}
          />
        </div>
    );
  }
}

export default Radar;