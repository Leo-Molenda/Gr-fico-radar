import {} from 'Componentes/GeradorDeGrafico'

export default function Button() {
    alert('wow')
}
