import styles from './Banner.module.css'
import PernaLonga from 'assets/PernaLonga.png'


export default function Banner() {
    return (
        <div className= {styles.Banner}>
            <div className= {styles.apresentacao}>
                <h1 className= {styles.titulo}> 
                    Titulo Do banner
                </h1>
                <p className= {styles.paragrafo}>
                    Paragrafo inicial do Banner
                </p>
            </div>

            <div className={styles.imagens}>
                <img 
                    className={styles.PernaLonga}
                    src={PernaLonga}
                    alt="ImagemDobanner"
                    aria-hidden={true}
                />
            </div>
        </div>
    )
}