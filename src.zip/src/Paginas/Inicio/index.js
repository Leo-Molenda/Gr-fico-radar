import Banner from "Componentes/Banner";
import Button from "Componentes/Button";
import React from "react";


export default function inicio() {
    return(
        <main>
        <Banner/>
        <h1>Tela de Inicio</h1>
        <div>
            <button onClick={Button}>
                Botão
            </button>
            <button onClick={Button}>
                Botão
            </button>
            <button onClick={Button}>
                Botão
            </button>
            <button onClick={Button}>
                Botão
            </button>
        </div>
        </main>
    )
}
