
import Radar from 'Componentes/GeradorDeGrafico'
import 'react-svg-radar-chart/build/css/index.css'

export default function GraficoGerado() {
    return (
        <Radar/>
    )
}